﻿namespace Exam16JAN
{
    public class Country
    {
        public Name Name { get; set; }
               
    }
    public class Name
    {
        public string Common { get; set; }
        public string Official { get; set; }
    }
}
